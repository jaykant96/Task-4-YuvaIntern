# HR Analytics – Employee Attrition Analysis Project

## Project overview
This project analyses employee attrition using the provided `HR_Analytics.csv` dataset. It includes a detailed Word report, Jupyter Notebook, original dataset, cleaned-data workflow, group-wise attrition charts, and Excel/CSV result files.

## Folder contents
- `data/HR_Analytics.csv` — source dataset supplied for the task.
- `notebooks/HR_Analytics_Analysis.ipynb` — executable analysis notebook.
- `reports/HR_Analytics_Data_Science_Tool_Mastery_Report.docx` — report for the Data Science Tool Mastery task.
- `reports/HR_Analytics_Long_Detailed_Report.docx` — extended report.
- `outputs/HR_Analytics_Results.xlsx` — computed result tables.
- `outputs/overall_summary.csv` — overall summary.
- `outputs/charts/` — chart images for report use.

## How to run on a laptop
1. Extract the ZIP file into a folder.
2. Open Command Prompt/Terminal in the extracted folder.
3. Install Python 3 if it is not already installed.
4. Install the required libraries:
   `pip install pandas numpy matplotlib openpyxl jupyter`
5. Start Jupyter:
   `jupyter notebook`
6. Open `notebooks/HR_Analytics_Analysis.ipynb`.
7. Run the notebook cells from top to bottom. Keep the `data` folder beside `notebooks`.

If using VS Code, open the extracted project folder, install the Python and Jupyter extensions, open the `.ipynb` file, select a Python kernel, and choose **Run All**.

## Main analysis questions
- What proportion of employees left the company?
- How does attrition vary by department and job role?
- Is attrition different for employees who work overtime?
- How do age groups, salary slabs, marital status, business travel and education fields compare?
- What data quality issues should be considered?
- What fair, practical actions could HR investigate?

## Data cleaning
The notebook reports the original shape and duplicate count, fills missing `YearsWithCurrManager` values with the median when the column exists, and removes exact duplicate rows. The notebook keeps the source CSV unchanged.

## Important interpretation note
This is descriptive analysis. Group differences are patterns, not proof of causation. HR recommendations should be checked with employee feedback, workload, satisfaction, compensation, career growth, and other relevant factors. Avoid making employment decisions based solely on demographic group membership.

## Submission note
Review the Word report and add your name/college details if required before submitting. Confirm that the report's figures and outputs match the latest notebook run. Do not claim a GitHub repository URL unless you have actually uploaded the project and verified the repository link.
